"""Workflow script T2E analysis using German Breast Cancer Study group 2."""

import os
import socket

# OPENBLASE config needs to be before pandas, autosk
# os.environ["OPENBLAS_NUM_THREADS"] = "1"
import pandas as pd

from octopus import OctoData, OctoML
from octopus.config import ConfigManager, ConfigSequence, ConfigStudy
from octopus.modules import Octo

print("Notebook kernel is running on server:", socket.gethostname())
print("Conda environment on server:", os.environ["CONDA_DEFAULT_ENV"])
# show directory name
print("Working directory: ", os.getcwd())


# load test dataset from Martin from csv and perform pre-processing
# stored in ./datasets_local/ to avoid accidental uploading to github
data = pd.read_csv("./datasets/gbs2.csv", index_col=0)
# data pre-processing
# check for NaNs
assert not pd.isna(data).any().any()

# one-hot encoding of categorical columns
columns = ["horTh", "menostat", "tgrade"]
df_list = [data]
for column in columns:
    df_list.append(pd.get_dummies(data[column], prefix=column, drop_first=True))
data_processed = pd.concat(df_list, axis=1)
for column in columns:
    data_processed.drop(column, axis=1, inplace=True)

# convert boolean columns to int
# Find the boolean columns
boolean_columns = data_processed.select_dtypes(include=bool).columns

# Convert boolean columns to int
data_processed[boolean_columns] = data_processed[boolean_columns].astype(int)
# create patient ID
data_processed.reset_index(inplace=True)
data_processed.rename(columns={"index": "patient"}, inplace=True)

### Create OctoData Object

# We define the data, target columns, feature columns, sample ID to identify groups,
# and the data split type. For this classification approach,
# we also define a stratification column.
octo_data = OctoData(
    data=data_processed,
    target_columns=[
        "Event",
        "Duration",
    ],
    feature_columns=[
        "age",
        "estrec",
        "pnodes",
        "progrec",
        "tsize",
        "horTh_yes",
        "menostat_Pre",
        "tgrade_II",
        "tgrade_III",
    ],
    sample_id="patient",
    datasplit_type="sample",
    target_asignments={"event": "Event", "duration": "Duration"},
)

### Create Configuration

# We create three types of configurations:
# 1. `ConfigStudy`: Sets the name, machine learning type (classification),
# and target metric.

# 2. `ConfigManager`: Manages how the machine learning will be executed.
# We use the default settings.

# 3. `ConfigSequence`: Defines the sequences to be executed. In this example,
# we use one sequence with the `RandomForestClassifier` model.

config_study = ConfigStudy(
    name="Survial-Test",
    ml_type="timetoevent",
    target_metric="CI",
    metrics=["CI"],
    datasplit_seed_outer=1234,
    n_folds_outer=5,
    start_with_empty_study=True,
    path="./studies/",
    silently_overwrite_study=True,
)

config_manager = ConfigManager(
    # outer loop parallelization
    outer_parallelization=True,
    # only process first outer loop experiment, for quick testing
    run_single_experiment_num=1,
)

config_sequence = ConfigSequence(
    [
        # Step1: octo
        Octo(
            description="step1_octo",
            # datasplit
            n_folds_inner=5,
            datasplit_seed_inner=0,
            # model training
            models=["ExtraTreesSurv"],
            model_seed=0,
            n_jobs=1,
            dim_red_methods=[""],
            max_outl=0,
            fi_methods_bestbag=["permutation"],
            # parallelization
            inner_parallelization=True,
            n_workers=5,
            # HPO
            optuna_seed=0,
            n_optuna_startup_trials=10,
            resume_optimization=False,
            global_hyperparameter=True,
            n_trials=10,
            max_features=0,
            penalty_factor=10.0,
        ),
        # Step2: ....
    ]
)

### Execute the Machine Learning Workflow

# We add the data and the configurations defined earlier
# and run the machine learning workflow.
octo_ml = OctoML(
    octo_data,
    config_study=config_study,
    config_manager=config_manager,
    config_sequence=config_sequence,
)
octo_ml.create_outer_experiments()
octo_ml.run_outer_experiments()

print("Workflow completed")

# This completes the basic example for using Octopus Classification
# with the Titanic dataset. The workflow involves loading and preprocessing
# the data, creating necessary configurations, and executing the machine
# learning pipeline.
