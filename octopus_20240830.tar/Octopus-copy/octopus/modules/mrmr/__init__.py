"""Init Mrmr."""
