"""Init test."""
